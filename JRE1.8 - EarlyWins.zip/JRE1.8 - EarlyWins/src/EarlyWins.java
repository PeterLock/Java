import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JEditorPane;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerListModel;

public class EarlyWins {
	
	private static JFrame frame;
	public static JPanel panel;
	private static JPanel container;
	private static String[] criteria; 
	private static SpinnerListModel criteriaModel1;
	private static SpinnerListModel criteriaModel2;
	private static SpinnerListModel criteriaModel3;
	private static SpinnerListModel criteriaModel4;

	
	
	
	private static JSpinner spinner1;
	private static JSpinner spinner2;
	private static JSpinner spinner3;
	private static JSpinner spinner4;
	private static JTextField name;
	public static int colSize;

	
	public static void main(String[] args){
		run();
	}
	
	
	public static void run() {
		initializeFields();
		
		frame = new JFrame();
		panel = new JPanel(new BorderLayout());
		
		
		frame.add(panel);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setSizes();
		
		addNorthRegion();
		addCenterRegion();
		addSouthRegion();
		
	}

	/* Method name: addSouthRegion
	 * ---------------------------
	 * This method will contain the total score based upon the options selected from the JSpinners
	 * in the center region.
	 * Precondition: none
	 * Postcondition: Contents displayed to screen
	 */
	public static void addSouthRegion() {
		int height = 50;
		Dimension dimension = new Dimension(SCREEN_SIZE.width, height);
		
		JPanel maincontainer = new JPanel();
		maincontainer.setLayout(new BoxLayout(maincontainer, BoxLayout.Y_AXIS));

		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		JLabel label = new JLabel("The total score from your selections is: ");

		String stringText = "<font face=arial><b>The result will be a number between 0 and 16 that is a rough measure you can use to compare the "
							+ "attractiveness of candidate focal points. Use common sense in interpreting these numbers. If the "
							+ "candidate scores 0 on the first question, for example, it doesnt matter if it scores 4's on all "
							+ "others.</b></font>";
		
		Font newFont = new Font(label.getName(), Font.BOLD, label.getFont().getSize());
		label.setFont(newFont);
		
		container.add(label);
		
		JTextField textField = new JTextField(20);
		container.add(textField);
		
		maincontainer.add(container);
		
		
		JPanel txtContainer = new JPanel(new GridBagLayout());
		txtContainer.setBackground(Color.WHITE);
		
		GridBagConstraints gc = new GridBagConstraints();

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,20,0,5);
		
		JEditorPane textArea = new JEditorPane();
		textArea.setContentType("text/html");
		    
		    
		textArea.setEditable(true);
		textArea.setText(stringText);
		
		JScrollPane scrollPane = new JScrollPane( textArea );
		scrollPane.setPreferredSize(new Dimension(dimension.width/2, 90));
		scrollPane.setBorder(null);
		
		txtContainer.add(scrollPane, gc);
		
		maincontainer.add(txtContainer);
		maincontainer.add(Box.createVerticalStrut(30));

		
		
		panel.add(maincontainer, BorderLayout.SOUTH);
		
	}


	public static void addCenterRegion() {
		
		container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		row1.setMaximumSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height/4/5));
		JLabel label = new JLabel("For each of the following questions, circle the response that best describes the potential.");
		
		Font newFont = new Font(label.getName(), Font.ITALIC, label.getFont().getSize());
		label.setFont(newFont);
		row1.add(label);

		container.add(row1);
		
		//Add generic panels with left and right regions//
		JPanel criteria1 = getGenPanel(1);
		JPanel criteria2 = getGenPanel(2);
		JPanel criteria3 = getGenPanel(3);
		JPanel criteria4 = getGenPanel(4);
		
		container.add(Box.createVerticalStrut(30));
		container.add(criteria1);
		container.add(criteria2);
		container.add(criteria3);
		container.add(criteria4);
		
		panel.add(container, BorderLayout.CENTER);
	}


	public static JPanel getGenPanel(int number) {
		int height = 60;
		
		Dimension dimension = new Dimension(SCREEN_SIZE.width, height);

		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.setPreferredSize(dimension);
		panel.setMaximumSize(dimension);

		//Random colors//
/*		int r = (int)Math.round(Math.random() * 255);
		int g = (int)Math.round(Math.random() * 255);
		int b = (int)Math.round(Math.random() * 255);

		Color color = new Color(r,g,b);*/
		
		panel.setBackground(Color.WHITE);
		
		//Setup left and right regions//
		JPanel left = new JPanel(new GridBagLayout());
		left.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		left.setMaximumSize(new Dimension(dimension.width/2, dimension.height));
		left.setSize(new Dimension(dimension.width/2, dimension.height));

		
		GridBagConstraints gc = new GridBagConstraints();

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,20,0,0);

		
		JTextArea textArea = getTextArea(number);
		left.add(textArea, gc);
		left.setBackground(Color.WHITE);
		
		
		JPanel right = new JPanel();
		right.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		right.setMaximumSize(new Dimension(dimension.width/2, dimension.height));
		right.setBackground(Color.WHITE);
		
		switch(number){
		case 1: {
			right.add(spinner1);
		}
		case 2: {
			right.add(spinner2);
		}
		case 3: {
			right.add(spinner3);
		}
		case 4: {
			right.add(spinner4);
		}
		default:
		}
		
		panel.add(left);
		panel.add(right);
		
		return panel;
	}


	public static JTextArea getTextArea(int i) {
		int height = 80;
		
		Dimension dimension = new Dimension(SCREEN_SIZE.width, height);
		
		String string1 = "Does the focal point offer an opportunity to make a"
						+ "substantial improvement in the performance of your unit?";
		
		String string2 = "Is this improvement achievable in a reasonably short time"
						+ " with available resources?";
		
		String string3 = "Would success also help lay the foundation for achieving"
						+ "agreed-to business goals?";
		
		String string4 = "Will the process used to achieve the win help you make "
						+ "needed change in behavior in the organization?";
		//Add the text//
		JTextArea textArea = new JTextArea(20, 30);
		
		switch( i ){
			case 1:{
				textArea.setText(string1);
				break;
				}
			case 2:{
				textArea.setText(string2);
				break;
				}
			case 3:{
				textArea.setText(string3);
				break;
				}
			case 4:{
				textArea.setText(string4);
				break;
				}
		default:
		}
		
		
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(true);
		
		JScrollPane scrollPane = new JScrollPane( textArea );
		scrollPane.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		
		return textArea;
	}


	/* Method name: addNorthernContent
	 * -------------------------------
	 * This method adds all of the required content for the northern region of the application
	 * Precondition: none
	 * Postcondition: Northern panel content has been added
	 */
	public static void addNorthRegion() {
		
		String textString = "This tool helps you asses the potential of candidates focal points for getting early wins."
							+ "Complete one for each candidates focal point, carefully answering the evaluation questions."
							+ "Then total the scores for the evaluation question, and use the result as a rough indicator"
							+ "of the potential";
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		
	
		
		row1.setMaximumSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height/4/5));
		row2.setMaximumSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height/4/5));

		JPanel northPanel = new JPanel();
		northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.Y_AXIS));
		northPanel.setPreferredSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height / 4));

		
		northPanel.setBackground(Color.WHITE);
		
		
		//Add each rows content//
		row1.add(new JLabel("TABLE 5-2"));
		row2.add(new JLabel("Early wins evaluation tool"));
		
		
		//Add rows to the northern panel//
		northPanel.add(row1);
		northPanel.add(row2);
		
		
		//Add the text//
		JTextArea textArea = new JTextArea(5, 20);
		textArea.setPreferredSize(new Dimension(SCREEN_SIZE.width/2-30, SCREEN_SIZE.height/4/4));
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setText(textString);
		textArea.setEditable(false);
		
		JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		row3.add(textArea);
		
		northPanel.add(row3);
		
		//Add Candidate name input box//
		JPanel row4 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		row4.setMaximumSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height/4/5));
		row4.add(new JLabel("CANDIDATE EARLY WIN:"));
		
		name = new JTextField(20);
		row4.add(name);
		
		
		
		//Set all panel background colors to white//
		setColors(row1);
		setColors(row2);
		setColors(row3);
		setColors(row4);

		northPanel.add(row4);

		
		panel.add(northPanel, BorderLayout.NORTH);
		
	}


	private static void setColors(JPanel panel) {
		panel.setBackground(Color.WHITE);
	}


	public static void initializeFields() {
		criteria = new String[] {	"Not at all",
									"To a small extent",
									"Somewhat",
									"To a signifcant extent",
									"To a great extent"};
		
		criteriaModel1 = new SpinnerListModel(criteria);
		criteriaModel2 = new SpinnerListModel(criteria);
		criteriaModel3 = new SpinnerListModel(criteria);
		criteriaModel4 = new SpinnerListModel(criteria);
		
		spinner1 = new JSpinner(criteriaModel1);
		spinner2 = new JSpinner(criteriaModel2);
		spinner3 = new JSpinner(criteriaModel3);
		spinner4 = new JSpinner(criteriaModel4);
		
		//Set spinner sizes//
		setSpinnerSize(spinner1);
		setSpinnerSize(spinner2);
		setSpinnerSize(spinner3);
		setSpinnerSize(spinner4);


	}


	private static void setSpinnerSize(JSpinner spinner) {
		Component mySpinnerEditor = spinner.getEditor();
		JFormattedTextField jftf = ((JSpinner.DefaultEditor) mySpinnerEditor).getTextField();		
		jftf.setColumns(12);
	}


	public static void setSizes() {
		frame.setSize(SCREEN_SIZE.width/2, SCREEN_SIZE.height);
		panel.setSize(SCREEN_SIZE.width/2, SCREEN_SIZE.height); 
		
		frame.setMaximumSize(new Dimension(SCREEN_SIZE.width/2, SCREEN_SIZE.height));
	}


	private static Dimension SCREEN_SIZE = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
}
