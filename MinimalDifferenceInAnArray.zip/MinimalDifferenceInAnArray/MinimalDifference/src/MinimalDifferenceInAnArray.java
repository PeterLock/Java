
public class MinimalDifferenceInAnArray {
	
	
	public static void main(String[] args){
		
		int[] array = {0,3,3,7,5,3,11,1};
		int difference = findMinDiff(array);
	
		System.out.println("Minimal difference is:" + difference);
	}

	private static int findMinDiff(int[] array) {
		
		int diff = 0;
		
		for(int i = 0; i < array.length-1; i++){
			
			for(int j = i + 1; j < array.length; j++){
				
				if((array[i] - array[j] < diff))
					diff = array[i] - array[j];
				
			}
			
		}
		
		return diff;
	}

}
