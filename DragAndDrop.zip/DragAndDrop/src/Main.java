import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * This is a Drag and Drop of a Person Object example. Reference:
 * http://zetcode.com/tutorials/javaswingtutorial/draganddrop/
 * 
 * By: PeterLock
 * */
public class Main extends JFrame {

	private JPanel contentPane;
	private JPanel leftPanel;
	private JPanel rightPanel;
	private JLabelPerson labelPerson;
	
	DataFlavor dataFlavor = new DataFlavor(Person.class,
			Person.class.getSimpleName());

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new Main().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("A Drag and Drop Example - PeterLock");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		leftPanel = new JPanel();
		leftPanel.setBackground(SystemColor.desktop);
		leftPanel.setBounds(5, 5, 186, 263);
		contentPane.add(leftPanel);

		labelPerson = new JLabelPerson(new Person());
		leftPanel.add(labelPerson);

		rightPanel = new JPanel();
		rightPanel.setBackground(Color.PINK);
		rightPanel.setBounds(251, 5, 186, 263);
		contentPane.add(rightPanel);

		init();
	}

	private void init() {
		DragSource ds = new DragSource();
		ds.createDefaultDragGestureRecognizer(labelPerson,
				DnDConstants.ACTION_COPY, new DragGestureListImp());

		new MyDropTargetListImp(rightPanel);
	}

	class TransferablePerson implements Transferable {

		private Person person;

		public TransferablePerson(Person ani) {
			this.person = ani;
		}

		@Override
		public DataFlavor[] getTransferDataFlavors() {
			return new DataFlavor[] { dataFlavor };
		}

		@Override
		public boolean isDataFlavorSupported(DataFlavor flavor) {
			return flavor.equals(dataFlavor);
		}

		@Override
		public Object getTransferData(DataFlavor flavor)
				throws UnsupportedFlavorException, IOException {

			if (flavor.equals(dataFlavor))
				return person;
			else
				throw new UnsupportedFlavorException(flavor);
		}
	}

	class DragGestureListImp implements DragGestureListener {

		@Override
		public void dragGestureRecognized(DragGestureEvent event) {
			Cursor cursor = null;
			JLabelPerson lblPerson = (JLabelPerson) event.getComponent();

			if (event.getDragAction() == DnDConstants.ACTION_COPY) {
				cursor = DragSource.DefaultCopyDrop;
			}
			Person person = lblPerson.getPerson();

			event.startDrag(cursor, new TransferablePerson(person));
		}
	}

	class MyDropTargetListImp extends DropTargetAdapter implements
			DropTargetListener {

		private DropTarget dropTarget;
		private JPanel panel;

		public MyDropTargetListImp(JPanel panel) {
			this.panel = panel;

			dropTarget = new DropTarget(panel, DnDConstants.ACTION_COPY, this,
					true, null);
		}

		public void drop(DropTargetDropEvent event) {
			try {
				Transferable tr = event.getTransferable();
				Person an = (Person) tr.getTransferData(dataFlavor);

				if (event.isDataFlavorSupported(dataFlavor)) {
					event.acceptDrop(DnDConstants.ACTION_COPY);
					this.panel.add(new JLabelPerson(an));
					event.dropComplete(true);
					this.panel.validate();
					return;
				}
				event.rejectDrop();
			} catch (Exception e) {
				e.printStackTrace();
				event.rejectDrop();
			}
		}
	}
}