import javax.swing.JLabel;


public class JLabelPerson extends JLabel{
	private Person person;

	public JLabelPerson(Person a){
		this.setPerson(a);
	}

	public void setPerson(Person person) {
		this.person = person;
		this.setText(person.getName() + " - " + person.getAge());
	}

	public Person getPerson() {
		return person;
	}
}