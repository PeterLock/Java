import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Foglamp {
	
	public static JFrame frame;
	public static JPanel panel;
	public static JPanel northRegion;
	public static JPanel centerRegion;
	public static JPanel southRegion;
	
	private static int textfieldSize = 20;
	
	public static void main(String[] args){
		
		run();
		
	}
	/* Method name: run
	 * ----------------
	 * Runs the program. Hides the functionality from being accessed directly
	 * Precondition: none
	 * Postcondition: Screen is displayed
	 */
	private static void run(){
		
		initializeFields();
		northernRegion();
		centeralRegion();
		
		frame.setVisible(true);

		
	}

	private static void centeralRegion() {
		
		int headerHeight = 20;
		
		JPanel container = new JPanel();
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		container.setBackground(DEFAULT_COLOR);
		
		JPanel headerPanel = new JPanel();
		headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.X_AXIS)); 
		
        Font font = new Font("Arial", Font.BOLD, 11);
        
        JLabel label1 = new JLabel("Questions");
        JLabel label2 = new JLabel("Answers");

        label1.setFont(font);
        label2.setFont(font);

		
		JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		left.add(label1);
		
		
		JPanel right = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		right.add(label2);

		
		
		headerPanel.setBackground(Color.GREEN);
		headerPanel.add(left);
		headerPanel.add(right);

		
		//Add content panels//
		JPanel row1 = getGenPanel(1);
		JPanel row2 = getGenPanel(2);
		JPanel row3 = getGenPanel(3);
		JPanel row4 = getGenPanel(4);
		JPanel row5 = getGenPanel(5);
		JPanel row6 = getGenPanel(6);
		JPanel row7 = getGenPanel(7);


		
		container.add(headerPanel);
		
		container.add(row1);
		container.add(row2);
		container.add(row3);
		container.add(row4);
		container.add(row5);
		container.add(row6);
		container.add(row7);

		
		panel.add(container, BorderLayout.CENTER);
	}
	
	public static JPanel getGenPanel(int number) {
		int height = 80;
		
		Dimension dimension = new Dimension(SCREEN_DIMENSION.width, height);

		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.setPreferredSize(dimension);
		panel.setMaximumSize(dimension);

		
		panel.setBackground(Color.WHITE);
		
		//Setup left and right regions//
		JPanel left = new JPanel(new GridBagLayout());
		left.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		left.setMaximumSize(new Dimension(dimension.width/2, dimension.height));
		left.setSize(new Dimension(dimension.width/2, dimension.height));

		
		GridBagConstraints gc = new GridBagConstraints();

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,5,5,5);

		
		left.setBackground(Color.WHITE);
		JScrollPane textArea = getTextArea(number);
		left.add(textArea, gc);

		
		
		JPanel right = new JPanel();
		right.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		right.setMaximumSize(new Dimension(dimension.width/2, dimension.height));
		right.setSize(new Dimension(dimension.width/2, dimension.height));
		right.setBackground(Color.WHITE);
		
		JScrollPane blankTextArea = getTextArea(9);
		right.add(blankTextArea, gc);
		
		
		
		panel.add(left);
		panel.add(right);
		
		return panel;
	}
	
	public static JScrollPane getTextArea(int i) {
		
		int height = 60;
		
		Dimension dimension = new Dimension(SCREEN_DIMENSION.width, height);
		
		String string1 = "Focus: What is the focus for this project? "
						+ "For example, what goal or early win do you want to achieve?";
		
		String string2 = "Oversight: How will you oversee this project? Who else should "
						+ "participate in oversight to help you get buy-in for implementing "
						+ "results?";
		
		String string3 = "Goals: What are the goals and the intermediate milestones and time "
						+ "frames for achieving them?";
		
		String string4 = "Leadership: Who will lead this project? What training, if any, do "
						+ "they need in order to be successful?";
		
		String string5 = "Abilities: What mix of skills and representation needs to be included? "
						+ "Who needs to be included because of their skills? Because the represent "
						+ "key constituencies?";
		
		String string6 = "Means: What additional resources, such as facilitation, does the team "
						+ "need to be successful?";
		
		String string7 = "Process: Are their change models or structured processes you want to "
						+ "use? If so, how will they become familiar with the approach?";
		
		
		
		//Add the text//
		JTextArea textArea = new JTextArea(3, 3);
		textArea.setBorder(null);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		
		switch( i ){
			case 1:{
				textArea.setText(string1);
				break;
				}
			case 2:{
				textArea.setText(string2);
				break;
				}
			case 3:{
				textArea.setText(string3);
				break;
				}
			case 4:{
				textArea.setText(string4);
				break;
				}
			case 5:{
				textArea.setText(string5);
				break;
				}
			case 6:{
				textArea.setText(string6);
				break;
				}
			case 7:{
				textArea.setText(string7);
				break;
				}
			case 9:{
				Border border = BorderFactory.createLineBorder(Color.BLACK);
				textArea.setBorder(BorderFactory.createCompoundBorder(border, 
				            BorderFactory.createEmptyBorder(10,10,10,10)));
				
				
				JTextArea newArea = new JTextArea(3,25);
				JScrollPane scroller = new JScrollPane(newArea);
				//scroller.setPreferredSize(new Dimension(dimension.width/2-20, dimension.height));
				//.setMaximumSize(new Dimension(dimension.width/2-20, dimension.height));


				
				return scroller;			
				}
		default:
		}
		
        Font font = new Font("Arial", Font.PLAIN, 11);
        textArea.setFont(font);
		
		JScrollPane scrollPane = new JScrollPane( textArea );
		scrollPane.setBorder(null);
		scrollPane.setPreferredSize(new Dimension(dimension.width/2, dimension.height));
		
		return scrollPane;
	}
	
	/* Method name: northernRegion
	 * ---------------------------
	 * This method adds all of the components needed to complete the northern most region of the screen
	 * Precondition: none
	 * Postcondition: Components added
	 */
	private static void northernRegion() {
		//Set north regions height to 1/5 of the screen height//
		int height = SCREEN_DIMENSION.height/4;
		int p1Height = SCREEN_DIMENSION.height/4/4;
		
		String textString = "FOGLAMP is an acronym for focus, oversight, goals, leadership, abilities, means, and process. "
							+ "This tool can help you cut through the haze and plan your critical projects. Complete the fields "
							+ "below for each early-win project you set up.";
		
		JPanel row2;
		JPanel row3;
		
		northRegion = new JPanel();
		northRegion.setLayout(new BoxLayout(northRegion, BoxLayout.Y_AXIS));
		northRegion.setSize(SCREEN_DIMENSION.width/2, height);
		northRegion.setPreferredSize(new Dimension(SCREEN_DIMENSION.width/2, height));
		northRegion.setBackground(DEFAULT_COLOR);
		
		row2 = setPanelSizes(p1Height);
		JLabel label = new JLabel("SECTION 5-3");
		Font newFont = new Font(label.getName(), Font.BOLD, label.getFont().getSize());
		label.setFont(newFont);
		row2.add(label);
		
		row3 = setPanelSizes(p1Height);
		JLabel label1 = new JLabel("FOGLAMP project checklist");
		label1.setFont(newFont);
		row3.add(label1);
		
		
		//Add the text//
		JTextArea textArea = new JTextArea();
		textArea.setPreferredSize(new Dimension(SCREEN_DIMENSION.width/2-30, SCREEN_DIMENSION.height/4/4));
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setText(textString);
		textArea.setEditable(false);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBorder(null);
		
		JPanel row4 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		row4.add(scrollPane);
		row4.setBackground(DEFAULT_COLOR);
		
		northRegion.add(row2);
		northRegion.add(row3);
		northRegion.add(row4);
		
		row4.revalidate();
		
		JPanel row5 = setPanelSizes(p1Height);
		row5.add(new JLabel("Project: "));
		
		JTextField textField = new JTextField(textfieldSize);
		row5.add(textField);

		northRegion.add(row5);
		
		panel.add(northRegion, BorderLayout.NORTH);
	}

	private static JPanel setPanelSizes(int height) {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		panel.setPreferredSize(new Dimension(SCREEN_DIMENSION.width/2, height));
		panel.setMaximumSize(new Dimension(SCREEN_DIMENSION.width/2, height));
		panel.setBackground(DEFAULT_COLOR);
		return panel;
	}
	
	private static void initializeFields() {
		frame = new JFrame();
		frame.setSize(SCREEN_DIMENSION.width/2, SCREEN_DIMENSION.height);
		frame.setMaximumSize(new Dimension(SCREEN_DIMENSION.width/2, SCREEN_DIMENSION.height));

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel = new JPanel(new BorderLayout());
		panel.setSize(SCREEN_DIMENSION.width/2, SCREEN_DIMENSION.height);
		frame.add(panel);
	}

	private static final Dimension SCREEN_DIMENSION = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
	private static final Color DEFAULT_COLOR = Color.WHITE;
}
